#!/usr/bin/env python
# -*- coding: utf-8 -*-  
# by zhangzhi @2013-11-13 23:31:35 
# Copyright 2013 NONE rights reserved.
import util
import pca
import numpy as np
import sys
import matplotlib.pyplot as plt

if __name__ == '__main__':
    for i in range(3):
        print "dealing with %d" % (i)
        X = util.load_data(i, 5000)
        mean = np.mean(X, 0)
        util.display(mean, '%d_mean.png' % (i))
        evecs, evals = pca.pcaSvd(X)
        #test =  [ float(each) for each in evecs[0] ] 
        for j in range(20):
            util.display(evecs[j], '%d_evec_%d.png' % (i, j))
        plt.figure('eigenvalues of %s' % (i))
        plt.plot(evals[:100])
        plt.xlabel("Ranks")
        plt.ylabel("EigenValues") 
        plt.show()


    Y = util.load_data_in_dir('train012')
    mean = np.mean(Y, 0)
    util.display(mean, '012_mean.png')
    evecs, evals = pca.pcaSvd(Y)
    for j in range(20):
        util.display(evecs[j], '012_evec_%d.png' % (j))
    plt.figure('eigenvalues of 012')
    plt.plot(evals[:100])
    plt.xlabel("Ranks")
    plt.ylabel("EigenValues") 
    plt.show()


